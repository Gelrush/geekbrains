namespace _geek
{
	int summ(int a, int b) {
		return a + b;
	}
}

