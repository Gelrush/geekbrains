#include <iostream>
#include "01_Space-geek.h"

using namespace _geek;

int main(int argc, char **args) {
	std::cout << summ(3, 4) << std::endl;
	return 0;
}
