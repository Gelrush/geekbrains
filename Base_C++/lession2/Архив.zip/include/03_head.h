int funct(int a, int b);
